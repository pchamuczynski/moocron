import sys
import textwrap

import random

def generate_fake_quote():
    """
    Generates a random fake quote from a politician by selecting one element
    from each of four predefined parts.
    
    Returns:
        str: A constructed fake quote.
    """
    
    # 1st Part: Introductory Phrases
    intro_phrases = [
        "We have to remember that",
        "I will always say:",
        "You can be sure that when I'm in charge",
        "It's imperative to understand that",
        "Let me make it clear:",
        "We must acknowledge that",
        "I firmly believe that",
        "Rest assured,",
        "It's time to recognize that",
        "Make no mistake,"
    ]
    
    # 2nd Part: Policy Statements
    policy_statements = [
        "lowering the taxes for the filthy rich",
        "making filthy rich people even richer",
        "increasing the income of the wealthy elite",
        "helping billionaires expand their empires",
        "reducing regulations on large corporations",
        "promoting tax breaks for big businesses",
        "enhancing subsidies for multinational companies",
        "encouraging investment by the financial sector",
        "cutting funding for social programs",
        "deregulating industries to boost profits"
    ]
    
    # 3rd Part: Rationale
    rationales = [
        "will return as a golden rain on the rest of society",
        "will cheer up the poorer segments of the population",
        "will stimulate economic growth nationwide",
        "will create a ripple effect benefiting all citizens",
        "will ensure prosperity spreads across the nation",
        "will lead to widespread financial well-being",
        "will result in increased job opportunities for everyone",
        "will foster a thriving and robust economy",
        "will pave the way for unprecedented national success",
        "will guarantee a brighter future for all"
    ]
    
    # 4th Part: Metaphorical Conclusions
    metaphors = [
        "as the tide rises all boats.",
        "because karma will return to us.",
        "just like a snowball rolling down a hill gathers more snow.",
        "similar to how planting seeds leads to a bountiful harvest.",
        "much like how the sun rises each morning without fail.",
        "as gravity keeps the planets in orbit.",
        "because a rising tide lifts all ships.",
        "just as the roots support the tallest trees.",
        "much like how a spark ignites a blazing fire.",
        "because every action has its equal and opposite reaction."
    ]
    
    # Randomly select one element from each part
    intro = random.choice(intro_phrases)
    policy = random.choice(policy_statements)
    rationale = random.choice(rationales)
    metaphor = random.choice(metaphors)
    
    # Construct the full quote
    quote = f"{intro} {policy}, {rationale} {metaphor}"
    
    return quote


def print_cowsay(message):
    # Define the cow ASCII art
    cow = r"""
           ^__^         __
           (oo)\_______/
           (__)\       )
               ||----w |\  
               ||     || \ 
    """
    cpw = textwrap.dedent(cow).strip()

    # Wrap the message to a maximum width (optional)
    max_width = 40
    wrapped = textwrap.wrap(message, width=max_width)
    if not wrapped:
        wrapped = ['']

    # Determine the width of the speech bubble
    max_len = max(len(line) for line in wrapped)
    border = ' ' * 27 + '-' * (max_len + 2)
    
    # Print the cow
    print(cow)

    # Print the speech bubble
    print(border)
    for i, line in enumerate(wrapped):
        if len(wrapped) == 1:
            print(' ' * 25 + f"< {line} >")
        else:
            if i == 0:
                print(' ' * 25 + f"/ {line.ljust(max_len)}  \\")
            elif i == len(wrapped) - 1:
                print(' ' * 25 + f"\\ {line.ljust(max_len)}  /")
            else:
                print(' ' * 25 + f"| {line.ljust(max_len)} |")
    print(border)


def main():
    
    # Combine all arguments into a single message
    message = generate_fake_quote()
    print_cowsay(message)

if __name__ == "__main__":
    main()
